#ifndef POINT_HEADER
#define POINT_HEADER

struct Point
{
	float x;
	float y;
	float z;
};

#endif // !POINT_HEADER